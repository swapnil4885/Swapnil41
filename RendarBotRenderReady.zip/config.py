# Telegram Bot Token
BOT_TOKEN = "8306875717:AAG34WyLvyi9qvCzQ4mppqUpu3TweHSTrO4"

# Google Sheets setup
SHEET_NAME = "Bot Data"
SHEET_ID = "17sooIHix_zMWDLi4YlUGOljXhMcE8Q78h9RnaGfXE7I"
SERVICE_ACCOUNT_FILE = "service_account.json"
